import cv2
from ultralytics import YOLO

# Load the YOLO model
model = YOLO('Run/weights/best_g2.pt')

# Use webcam as video input (0 is the default webcam index, adjust if multiple webcams are connected)
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("Error: Could not open webcam.")
    exit()

while cap.isOpened():
    # Read a frame from the webcam
    success, frame = cap.read()

    if success:
        # Run YOLO model on the frame
        results = model(frame)
        
        # Annotate the frame with detection results
        annotated_frame = results[0].plot()
        
        # Display the annotated frame
        cv2.imshow("Weapon Detection (Webcam)", annotated_frame)

        # Break the loop if 'q' is pressed
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break
    else:
        print("Error: Failed to read frame from webcam.")
        break

# Release the webcam and close all OpenCV windows
cap.release()
cv2.destroyAllWindows()
